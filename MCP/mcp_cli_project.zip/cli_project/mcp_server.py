from pydantic import Field
from mcp.server.fastmcp import FastMCP
from mcp.server.fastmcp.prompts import base
from pathlib import Path
from mcp.server.fastmcp import Context
from core.video_converter import VideoConverter
from core.utils import file_url_to_path

mcp = FastMCP("DocumentMCP", log_level="ERROR")


docs = {
    "deposition.md": "This deposition covers the testimony of Angela Smith, P.E.",
    "report.pdf": "The report details the state of a 20m condenser tower.",
    "financials.docx": "These financials outline the project's budget and expenditures.",
    "outlook.pdf": "This document presents the projected future performance of the system.",
    "plan.md": "The plan outlines the steps for the project's implementation.",
    "spec.txt": "These specifications define the technical requirements for the equipment.",
}

async def is_path_allowed(requested_path: Path, ctx: Context) -> bool:
    roots_result = await ctx.session.list_roots()
    client_roots = roots_result.roots

    if not requested_path.exists():
        return False

    if requested_path.is_file():
        requested_path = requested_path.parent

    for root in client_roots:
        root_path = file_url_to_path(root.uri)
        try:
            requested_path.relative_to(root_path)
            return True
        except ValueError:
            continue

    return False

@mcp.tool()
async def list_roots(ctx: Context):
    """
    List all directories that are accessible to this server.
    These are the root directories where files can be read from or written to.
    """
    roots_result = await ctx.session.list_roots()
    client_roots = roots_result.roots

    return [file_url_to_path(root.uri) for root in client_roots]

@mcp.tool()
async def convert_video(
    input_path: str = Field(description="Path to the input MP4 file"),
    format: str = Field(description="Output format (e.g. 'mov')"),
    *,
    ctx: Context,
):
    """Convert an MP4 video file to another format using ffmpeg"""
    input_file = VideoConverter.validate_input(input_path)

    # Ensure the input file is contained in a root
    if not await is_path_allowed(input_file, ctx):
        raise ValueError(f"Access to path is not allowed: {input_path}")

    return await VideoConverter.convert(input_path, format)

@mcp.tool()
async def read_dir(
    path: str = Field(description="Path to a directory to read"),
    *,
    ctx: Context,
):
    """Read directory contents. Path must be within one of the client's roots."""
    requested_path = Path(path).resolve()

    if not await is_path_allowed(requested_path, ctx):
        raise ValueError("Error: can only read directories within a root")

    return [entry.name for entry in requested_path.iterdir()]

# TODO: Write a tool to read a doc
@mcp.tool(
	name = "read_doc_contents",
	description = "Read the contents of a document and return it as a string"
)
def read_docment(
	doc_id: str = Field(description = "Id of the document to read")
):
	if doc_id not in docs:
		raise ValueEoor(f"Doc with id {doc_id} not found")

	return docs[doc_id]

# TODO: Write a tool to edit a doc
@mcp.tool(
	name = "edit_document",
	description = "Edit a document by replacing a string in the documents content with a new string"
)
def edit_document(
	doc_id: str = Field(description = "Id of the document to edit"),
	old_str: str = Field(description = "The text to replace. Must match exactly, including whitespace"),
	new_str: str= Field(description = "The new text to insert in place of the old text")
):
	if doc_id not in docs:
		raise ValueEoor(f"Doc with id {doc_id} not found")

	docs[doc_id] = docs[doc_id].replace(old_str, new_str)
# TODO: Write a resource to return all doc id's
@mcp.resource(
	"docs://documents",
	mime_type="application/json"
)
def list_docs() -> list[str]:
	return list(docs.keys())

# TODO: Write a resource to return the contents of a particular doc
@mcp.resource(
	"docs://documents/{doc_id}",
	mime_type="text/plain"
)
def fetch_doc(doc_id: str) -> str:
	if doc_id not in docs:
		raise ValueEoor(f"Doc with id {doc_id} not found")

	return docs[doc_id]
# TODO: Write a prompt to rewrite a doc in markdown format
@mcp.prompt(
	name = "format",
	description = "Rewrites the contents of the document in Markdown format."
)
def format_document(
	doc_id:str = Field(description = "Id of the document to format")
) -> list[base.Message]:
	prompt = f"""
Your goal is to reformat a document to be written with markdown syntax.

The id of the document you need to reformat is:
<document_id>
{doc_id}
</document_id>

Add in headers, bullet points, tables, etc as necessary. Feel free to add in structure.
Use the 'edit_document' tool to edit the document. After the document has been reformatted...
"""
	return [base.UserMessage(prompt)]
# TODO: Write a prompt to summarize a doc


if __name__ == "__main__":
    mcp.run(transport="stdio")
